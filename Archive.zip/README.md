# README

## Question 1
`cd q1`  
Compile with `./build.sh`.  
Run with `./run.sh`.

## Question 2
`cd q2`  
Compile with `./build.sh`.  
Run with `./run.sh`.
