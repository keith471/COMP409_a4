#/bin/bash

./q1 $1 $2 $3
