# README

NOTE: You will want to change the CC variable in the build scripts to provide a gcc that works on McGill's servers. Due to lack of time, I cannot test my code on the servers and check what gcc/flags to use.

## Question 1
`cd q1`  
Compile with `./build.sh`.  
Run with `./run.sh`.

## Question 2
`cd q2`  
Compile with `./build.sh`.  
Run with `./run.sh`.
