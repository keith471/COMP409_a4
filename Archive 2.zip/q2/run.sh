#/bin/bash

./q2 $1 $2 $3
